#include<xc.h>
#include"eeprom.h"
#include"i2c.h"

void write_eeprom(unsigned char address1,unsigned char data)
{
    i2c_start();
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address1);
    i2c_write(data);
    i2c_stop();
    for(unsigned long int delay=3000;delay--;);
}
unsigned char read_eeprom(unsigned char address1)
{
    unsigned char read;
    i2c_start();
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address1);
    for(unsigned int delay=3000;delay--;);
    i2c_rep_start();
    i2c_write(SLAVE_READ_E);
    read=i2c_read();
    i2c_stop();
    return read;
}