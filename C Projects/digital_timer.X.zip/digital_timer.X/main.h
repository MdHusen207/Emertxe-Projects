#ifndef MAIN_H
#define MAIN_H

typedef enum
{
    e_default_screen,e_config,e_config_mode,e_config_mode1,e_settime,e_setdate,e_setevent,e_viewevent
}state_t;
unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9], get_c_time[13],get_c_date[11];unsigned char set_arr[6],modes[4]="ODW";unsigned char event[9];
unsigned char date[11];unsigned char config[6][15]={"SET/VIEW EVENT ","SET TIME/DATE","SET TIME","SET DATE","SET EVENT","VIEW EVENT"};
unsigned char blink=0,time_flag=0,key=0,star=1,position=1,hour=0,min=0,sec=0,ind,year=0,month=0,date1=0,day=0,count_flag=0;
unsigned char position1=1,mode=0,index=0,index1=0,count=0,add=0x00,read=0x00,h1=0,m1=0,inde=0;unsigned int delay1=0,delay2=0,delay3=0;
unsigned char display[10][15];unsigned char hourflag=0,minflag=0,indflag=0,read1=0x00,stop_flag=0,add1=0x00,add2=0x00,pri_flag=0,main_flag=0,hour1=0,min1=0;
#endif