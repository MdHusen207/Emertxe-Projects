#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include"matrix.h"
#include"eeprom.h"
state_t state;
//functions to inital configuration
void init_config(void)
{
	init_clcd();
	init_i2c();
	init_ds1307();
    init_matrix();
    state=e_default_screen;
}
//display data
void display_date(void)
{
    clcd_print("DATE",LINE1(0));
	clcd_print(date, LINE1(5));
    clcd_putch(' ',LINE1(15));
}
//function to display time
void display_time(void)
{
    clcd_print("TIME  ",LINE2(0));
	clcd_print(time, LINE2(5));
    clcd_putch(' ',LINE2(13));
	if (clock_reg[0] & 0x40)
	{
		if (clock_reg[0] & 0x20)
		{
			clcd_print("PM", LINE2(14));
		}
		else
		{
			clcd_print("AM", LINE2(14));
		}
	}
}

static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}
//function to get date
static void get_date(void)
{
	calender_reg[0] = read_ds1307(YEAR_ADDR);
	calender_reg[1] = read_ds1307(MONTH_ADDR);
	calender_reg[2] = read_ds1307(DATE_ADDR);
	calender_reg[3] = read_ds1307(DAY_ADDR);

	date[0] = '2';
	date[1] = '0';
	date[2] = '0' + ((calender_reg[0] >> 4) & 0x0F);
	date[3] = '0' + (calender_reg[0] & 0x0F);
	date[4] = '/';
	date[5] = '0' + ((calender_reg[1] >> 4) & 0x0F);
	date[6] = '0' + (calender_reg[1] & 0x0F);
	date[7] = '/';
	date[8] = '0' + ((calender_reg[2] >> 4) & 0x0F);
	date[9] = '0' + (calender_reg[2] & 0x0F);
	date[10] = '\0';
}
//function to display time with event
void display_time1()
{
    clcd_print("TIME",LINE1(0));
	clcd_print(time, LINE1(5));
    clcd_putch(' ',LINE1(13));
	if (clock_reg[0] & 0x40)
	{
		if (clock_reg[0] & 0x20)
		{
			clcd_print(" PM", LINE1(13));
		}
		else
		{
			clcd_print(" AM", LINE1(13));
		}
	}
}
//function to read eeprom for ascending order store
void read_flag()
{
    hourflag=hourflag*10+read_eeprom(read1++)-48;
    hourflag=hourflag*10+read_eeprom(read1++)-48;
    read1++;
    minflag=minflag*10+read_eeprom(read1++)-48;
    minflag=minflag*10+read_eeprom(read1++)-48;
    indflag=read_eeprom(read1++);
    read1++;
}
//function to shift event 
void shift_address()
{
    for(int i=count;i>0;i--)
    {
        if(i!=stop_flag)
        {
        for(int j=0;j<7;j++)
        write_eeprom(((add1++)+i*7),read_eeprom((add2++)+(i-1)*7));
        add1=0;
        add2=0;
        }
        else break;
        
    }
    write_eeprom((add++)+stop_flag*7,hour1/10+'0');
    write_eeprom((add++)+stop_flag*7,hour1%10+'0');
    write_eeprom((add++)+stop_flag*7,':');
    write_eeprom((add++)+stop_flag*7,min1/10+'0');
    write_eeprom((add++)+stop_flag*7,min1%10+'0');
    write_eeprom((add++)+stop_flag*7,index);
    write_eeprom((add++)+stop_flag*7,mode);
    
}
//function to store event in ascending order
void priority()
{
    for(;main_flag==0;)
    {
        if(count>0)
        {
            read_flag();
            if(indflag>index)
            {
                shift_address();
                count++;
                main_flag=1;
            }
            else if(indflag<index)
            {   
                if(pri_flag==count)
                {
                    write_eeprom((add++)+count*7,hour1/10+'0');
                    write_eeprom((add++)+count*7,hour1%10+'0');
                    write_eeprom((add++)+count*7,':');
                    write_eeprom((add++)+count*7,min1/10+'0');
                    write_eeprom((add++)+count*7,min1%10+'0');
                    write_eeprom((add++)+count*7,index);
                    write_eeprom((add++)+count*7,mode);
                    count++;
                    main_flag=1;
                }
                else
                {
                    main_flag=0;
                    stop_flag++;
                    pri_flag++;
                    hourflag=0;
                    minflag=0;

                }
            }
            else
            {
                if(hourflag>hour1)
                {
                    shift_address();
                    count++;
                    main_flag=1;
                }
                else if(hourflag<hour1)
                {
                    if(pri_flag==count)
                    {
                        write_eeprom((add++)+count*7,hour1/10+'0');
                        write_eeprom((add++)+count*7,hour1%10+'0');
                        write_eeprom((add++)+count*7,':');
                        write_eeprom((add++)+count*7,min1/10+'0');
                        write_eeprom((add++)+count*7,min1%10+'0');
                        write_eeprom((add++)+count*7,index);
                        write_eeprom((add++)+count*7,mode);
                        count++;
                        main_flag=1;
                    }
                    else
                    {
                        main_flag=0;
                        stop_flag++;
                        pri_flag++;
                        hourflag=0;
                        minflag=0;

                    }
                }
                else
                {
                    if(minflag>min1)
                    {
                        shift_address();
                        count++;
                        main_flag=1;
                    }
                    else if(minflag<min1)
                    {
                       if(pri_flag==count)
                       {
                            write_eeprom((add++)+count*7,hour1/10+'0');
                            write_eeprom((add++)+count*7,hour1%10+'0');
                            write_eeprom((add++)+count*7,':');
                            write_eeprom((add++)+count*7,min1/10+'0');
                            write_eeprom((add++)+count*7,min1%10+'0');
                            write_eeprom((add++)+count*7,index);
                            write_eeprom((add++)+count*7,mode);
                            count++;
                            main_flag=1;
                        }
                        else
                        {
                            main_flag=0;
                            stop_flag++;
                            pri_flag++;
                            hourflag=0;
                        minflag=0;

                        }
                    }
                    else
                        main_flag=1;
                }
           }
        }
    else{
            write_eeprom((add++)+count*7,hour1/10+'0');
            write_eeprom((add++)+count*7,hour1%10+'0');
            write_eeprom((add++)+count*7,':');
            write_eeprom((add++)+count*7,min1/10+'0');
            write_eeprom((add++)+count*7,min1%10+'0');
            write_eeprom((add++)+count*7,index);
            write_eeprom((add++)+count*7,mode);
            count++;
            main_flag=1;
        }
    }
}
void store_event()
{
    priority();
}
//function to check gretest event than time
int check_flag()
{
    if(inde<indflag)
    return 1;
    else if(inde>indflag)
    return 2;
    else 
    {
       if(h1<hourflag)
       return 1;
       else if(h1>hourflag)
       return 2;
       else
       {
       if(m1<minflag)
       return 1;
       else if(m1>minflag)
       return 2;
       else
           return 1;
       }
    }
}
//function to get event to show on default screen
void get_event()
{
    h1=h1*10+time[0]-48;
    h1=h1*10+time[1]-48;
    m1=m1*10+time[3]-48;
    m1=m1*10+time[4]-48;
    inde=(clock_reg[0]&0x20)>>5;
    int ret=0;
    for(int i=0;i<count;i++)
    {
        read_flag();
        ret=check_flag();
        if(ret==1)
        {
        count_flag=1;
        break;
        }
        else if(ret==2)
        {   
            hourflag=0;
            minflag=0;
            indflag=0;
        }
    }
    if(count_flag==1){
    event[0]=hourflag/10+'0';
    event[1]=hourflag%10+'0';
    event[2]=':';
    event[3]=minflag/10+'0';
    event[4]=minflag%10+'0';
    event[5]=' ';
    if(indflag==0)
     event[6]='A';
    else
        event[6]='P';
    event[7]='M';
    event[8]='\0';
    }
    h1=0;
    m1=0;
    hourflag=0;
    minflag=0;
    read1=0;
}
//function to compare event and current time
int compare_alarm()
{
    for(int i=0;i<5;i++)
    {
        if(time[i]!=event[i])
        return 0;
    }
    return 1;
}
//function to show default screen
void view_default_screen()
{
    get_date();
    get_time();
    get_event();
    int ret1=compare_alarm();
    if(ret1==1)
    RB0=!RB0;
    else
        RB0=0;
    if(clock_reg[2]!=time_flag)
    {
    blink++;
    time_flag=clock_reg[2];
    }
    if(blink<=5){
    display_date();
    display_time();}
    else{
        display_time1();
        clcd_print("EVENT ",LINE2(0));
        if(count_flag!=0)
        {
        clcd_print(event,LINE2(6));
        clcd_print("  ",LINE2(14));
        }
        else
            clcd_print("NO_EVENT       ",LINE2(6));
    }
    if(blink>7)
    {
        blink=0;
    }
    count_flag=0;
}
//function to read date
void read_date()
{
    get_c_date[0]=date[0];
    get_c_date[1]=date[1];
    get_c_date[2]=date[2];
    get_c_date[3]=date[3];
    get_c_date[4]=date[4];
    get_c_date[5]=date[5];
    get_c_date[6]=date[6];
    get_c_date[7]=date[7];
    get_c_date[8]=date[8];
    get_c_date[9]=date[9];
    get_c_date[10]=date[10];
    year=year*10+date[2]-48;
    year=year*10+date[3]-48;
    month=month*10+date[5]-48;
    month=month*10+date[6]-48;
    date1=date1*10+date[8]-48;
    date1=date1*10+date[9]-48;
    
}
void read_time1()
{
    set_arr[0]=hour1/10+48;
    set_arr[1]=hour1%10+48;
    set_arr[2]=' ';
    set_arr[3]=min1/10+48;
    set_arr[4]=min1%10+48;
    set_arr[5]='\0';
}
void read_time()
{
    get_c_time[0]=time[0];
    get_c_time[1]=time[1];
    get_c_time[2]=time[2];
    get_c_time[3]=time[3];
    get_c_time[4]=time[4];
    get_c_time[5]=time[5];
    get_c_time[6]=time[6];
    get_c_time[7]=time[7];
    hour=hour*10+time[0]-48;
    hour=hour*10+time[1]-48;
    min=min*10+time[3]-48;
    min=min*10+time[4]-48;
    sec=sec*10+time[6]-48;
    sec=sec*10+time[7]-48;
    ind=(clock_reg[0]&0x20)>>5;
    get_c_time[8]=' ';
    get_c_time[9]=' ';
    if(ind==0){
    get_c_time[10]='A';
    get_c_time[11]='M';}
    else{
        get_c_time[10]='P';
        get_c_time[11]='M';
    }
    get_c_time[12]='\0';
}
//function to set time in rtc
void store_time(unsigned char time[])
{
    clock_reg[0]=hour/10<<4;
    clock_reg[0]=clock_reg[0]|hour%10;
    clock_reg[0]=clock_reg[0]|0x01<<6;
    clock_reg[0]=clock_reg[0]|ind<<5;
    clock_reg[1]=min/10<<4;
    clock_reg[1]=clock_reg[1]|min%10;
    clock_reg[2]=sec/10<<4;
    clock_reg[2]=clock_reg[1]|sec%10;
    write_ds1307(HOUR_ADDR,clock_reg[0]);
    write_ds1307(MIN_ADDR,clock_reg[1]);
    write_ds1307(SEC_ADDR,clock_reg[2]);
}
//function to to blink position while setting time
void read_position(unsigned char i,unsigned char i1)
{
    if(delay1>=500)
    {
        get_c_time[i]=' ';
        get_c_time[i1]=' ';
    }
    else
    {
        if(position==1)
        {
            get_c_time[0]='0'+hour/10;
            get_c_time[1]='0'+hour%10;
        }
        else if(position==2)
        {
            get_c_time[3]='0'+min/10;
            get_c_time[4]='0'+min%10;
        }
        else if(position==3)
        {
            get_c_time[6]='0'+sec/10;
            get_c_time[7]='0'+sec%10;
        }
        else if(position==4)
        {
            if(ind==0)
            get_c_time[10]='A';
            else
                get_c_time[10]='P';
            get_c_time[11]='M';
        }
    }
    if(delay1++==1000)
    {
        delay1=0;
    }
}
//functions to set date in rtc
void store_date()
{
    calender_reg[0]=year/10<<4;
    calender_reg[0]=calender_reg[0]|year%10;
    calender_reg[1]=month/10<<4;
    calender_reg[1]=calender_reg[1]|month%10;
    calender_reg[2]=date1/10<<4;
    calender_reg[2]=calender_reg[2]|date1%10;
    write_ds1307(YEAR_ADDR,calender_reg[0]);
    write_ds1307(MONTH_ADDR,calender_reg[1]);
    write_ds1307(DATE_ADDR,calender_reg[2]);
}
//function to blink position while setting date
void read_position1()
{
    if(delay2>=500)
    {
        if(position1==1)
        {
            get_c_date[0]=' ';
            get_c_date[1]=' ';
            get_c_date[2]=' ';
            get_c_date[3]=' ';
        }
        else if(position1==2)
        {
            get_c_date[5]=' ';
            get_c_date[6]=' ';
        }
        else if(position1==3)
        {
            get_c_date[8]=' ';
            get_c_date[9]=' ';
        }
    }
    else
    {
        if(position1==1)
        {
            get_c_date[0]='2';
            get_c_date[1]='0';
            get_c_date[2]='0'+(year/10);
            get_c_date[3]='0'+year%10;
        }
        else if(position1==2)
        {
             get_c_date[5]='0'+month/10;
            get_c_date[6]='0'+month%10;
        }
        else if(position1==3)
        {
             get_c_date[8]='0'+date1/10;
            get_c_date[9]='0'+date1%10;
        }
    }
    if(delay2++==1000)
    {
        delay2=0;
    }
}
//function to set date
void set_date()
{
    clcd_print("YEAR/MM/SS",LINE1(2));
    clcd_print(get_c_date,LINE2(2));
    if(key==1)
    {
        if(position1==1)
        {
            year++;
            if(year==101)
             year=0;
            get_c_date[2]='0'+(year/10);
            get_c_date[3]='0'+year%10;
        }
        if(position1==2)
        {
            month++;
            if(month==13)
            month=1;
            get_c_date[5]='0'+month/10;
            get_c_date[6]='0'+month%10;
        }
        if(position1==3)
        {
            date1++;
            if(month%2==0&&date1==30)
            {
                date1=1;
            }else if(month%2!=0&&date1==31)
            {
                date1=1;
            }
            get_c_date[8]='0'+date1/10;
            get_c_date[9]='0'+date1%10;
        }
    }
    if(key==2)
    {
        if(position1==3)
        position1=0;
        position1++;
        if(position1==2)
        {
            get_c_date[0]='2';
            get_c_date[1]='0';
            get_c_date[2]='0'+(year/10);
            get_c_date[3]='0'+year%10;
        }
        else if(position1==3)
        {
            get_c_date[5]='0'+month/10;
            get_c_date[6]='0'+month%10;
        }
        else if(position1==1)
        {
            get_c_date[8]='0'+date1/10;
            get_c_date[9]='0'+date1%10;
        }
    }
    read_position1();
}
//function to set time
void set_time()
{
    clcd_print("HH:MM:SS",LINE1(2));
    clcd_print("AM/PM",LINE1(11));
    clcd_print(get_c_time,LINE2(2));
    if(key==1)
    {
        if(position==1)
        {
            hour++;
            if(hour==13)
            hour=0;
            get_c_time[0]='0'+hour/10;
            get_c_time[1]='0'+hour%10;
        }
        else if(position==2)
        {
            min++;
            if(min==60)
                min=0;
            get_c_time[3]='0'+min/10;
            get_c_time[4]='0'+min%10;
        }
        else if(position==3)
        {
            sec++;
            if(sec==60)
                sec=0;
            get_c_time[6]='0'+sec/10;
            get_c_time[7]='0'+sec%10;
        }
        else if(position==4)
        {
            if(ind==1)
                ind=0;
            else 
                ind=1;
        }
    }
    if(key==2)
    {
        if(position==4)
            position=0;
        position++;
        if(position==2){
             get_c_time[0]='0'+hour/10;
            get_c_time[1]='0'+hour%10;
        }
        if(position==3){
            get_c_time[3]='0'+min/10;
            get_c_time[4]='0'+min%10;
           }
        if(position==4){
            get_c_time[6]='0'+sec/10;
            get_c_time[7]='0'+sec%10;
    }
        if(position==1)
        {
            if(ind==0)
            get_c_time[10]='A';
            else
                get_c_time[10]='P';
            get_c_time[11]='M';
        }
    }
       if(position==1)
        read_position(0,1);
        if(position==2)
        read_position(3,4);
        if(position==3)
        read_position(6,7);
         if(position==4)
        read_position(10,11);
}
//function to read event and show
void read_event()
{
    unsigned char temp,j;
    for(int i=0;i<count;i++)
    {
        for( j=0;j<14;j++)
        {
            if(j==5||j==6)
            display[i][j]=' ';
            else if(j==7)
            {
                if(read_eeprom(read++)==0)
                {
                    display[i][j]='A';
                }
                else
                    display[i][j]='P';
            }
            else if(j==8)
                display[i][j]='M';
            else if(j>8&&j<13)
                display[i][j]=' ';
            else if(j==13)
            {
                temp=read_eeprom(read++);
                if(temp==0)
                display[i][j]='O';
                else if(temp==1)
                    display[i][j]='D';
                else 
                    display[i][j]='W';
                
            }
            else
            display[i][j]=read_eeprom(read++);
        }
        display[i][j]='\0';
    }
}
//function to to blink position while setting event
void blink_position()
{
    if(delay3>=500)
    {
         if(position==4)
        {
            clcd_putch(' ',LINE2(13));
        }
        else if(position==3)
        {
       
           clcd_print("  ",LINE2(7));
        }
        else if(position==1)
        {
            set_arr[0]=' ';
            set_arr[1]=' ';
        }
        else if(position==2)
        {
            set_arr[3]=' ';
            set_arr[4]=' ';
        }
    }
    else
    {
         if(position==4)
        {
            clcd_putch(modes[mode],LINE2(13));
        }
        else if(position==3)
        {
            if(index==0)
                clcd_print("AM",LINE2(7));
            else
                clcd_print("PM",LINE2(7));
        }
        else if(position==1)
        {
            set_arr[0]=hour1/10+'0';
            set_arr[1]=hour1%10+'0';
        }
        else if(position==2)
        {
            set_arr[3]=min1/10+'0';
            set_arr[4]=min1%10+'0';
        }
    }
    if(delay3++==1000)
    {
        delay3=0;
    }
}
//function to set event
void set_event()
{
    clcd_print("HH MM AM/PM MOD",LINE1(0));
    clcd_print(set_arr,LINE2(0));
    if(index==0)
        clcd_print("AM",LINE2(7));
    else if(index==1)
        clcd_print("PM",LINE2(7));
    clcd_putch(modes[mode],LINE2(13));
    if(key==1)
    {
        if(position==1)
        {
            hour1++;
            if(hour1==13)
                hour1=0;
            set_arr[0]=hour1/10+'0';
            set_arr[1]=hour1%10+'0';
        }
        if(position==2)
        {
            min1++;
            if(min==60)
             min1=0;
            set_arr[3]=min1/10+'0';
            set_arr[4]=min1%10+'0';
        }
        if(position==3)
        {
            if(index==0)
                index=1;
            else
                index=0;
        }
        if(position==4)
        {
            mode++;
            if(mode==3)
            mode=0;
        }
    }
    if(key==2)
    {
        position++;
        if(position==5)
        position=1;
        if(position==2)
        {
            set_arr[0]=hour1/10+'0';
            set_arr[1]=hour1%10+'0';
        }
        if(position==3)
        {
             set_arr[3]=min1/10+'0';
            set_arr[4]=min1%10+'0';
        }
    }
    blink_position();
}
//function to to show first mainmenu
void view_config()
{
    if(key==2)
    {
        star=2;
    }if(key==1)
    {
        star=1;
    }
    if(star==1){
    clcd_print("*",LINE1(0));
    clcd_print(" ",LINE2(0));}else{
        clcd_print("*",LINE2(0));
    clcd_print(" ",LINE1(0));
    }
    clcd_print(config[0],LINE1(2));
    clcd_print(config[1],LINE2(2));
}
//function to view event
void view_event()
{
    if(key==1)
    {
        if(index1!=0)
        index1--;
    }
    if(key==2)
    {
        if(index1!=count)
        index1++;
    }
    clcd_print("HH:MM AM/PM MOD",LINE1(0));
    clcd_print(display[index1],LINE2(0));
}
//function to view sub menu 2
void view_config1()
{
    if(key==2)
    {
        star=2;
    }if(key==1)
    {
        star=1;
    }
    if(star==1){
    clcd_print("*",LINE1(0));
    clcd_print(" ",LINE2(0));}else{
        clcd_print("*",LINE2(0));
    clcd_print(" ",LINE1(0));
    }
    clcd_print(config[4],LINE1(3));
    clcd_print(config[5],LINE2(3));
}
//function to view main menu
void config_mode()
{
    if(key==2)
    {
        star=2;
    }if(key==1)
    {
        star=1;
    }
    if(star==1){
    clcd_print("*",LINE1(0));
    clcd_print(" ",LINE2(0));}else{
        clcd_print("*",LINE2(0));
    clcd_print(" ",LINE1(0));
    }
    clcd_print(config[2],LINE1(3));
    clcd_print(config[3],LINE2(3));
}
//function to main function
void main(void)
{
	init_config();
	while (1)
	{
        key=read_switches(STATE_CHANGE);
        if(key==3)
        {
            CLEAR_DISP_SCREEN;
            if(state==0)
            state=e_config;
            else if(star==2&&state==1)
            {
                state=e_config_mode;
                star=1;
            }
            else if(star==1&&state==1)
            {
                state=e_config_mode1;
                star=1;
            }
            else if(star==1&&state==2)
            {
                state=e_settime;
                get_time();
                read_time();
            }
            else if(star==2&&state==2)
            {
                state=e_setdate;
                get_date();
                read_date();
            }
            else if(star==1&&state==3)
            {
                state=e_setevent;
                //get_time();
                read_time1();
                hourflag=0;
                minflag=0;
                read1=0;
            }
            else if(star==2&&state==3)
            {
                state=e_viewevent;
                read_event();
            }
            else if(state==e_settime)
            {
                store_time(time);
                position=1;
                hour=sec=min=0;
                state=e_config_mode;
                star=1;
            }
            else if(state==e_setdate)
            {
               store_date();
                position1=1;
                year=month=date1=0;
                state=e_config_mode;
                star=1;
            }
            else if(state==e_setevent)
            {
                store_event();
                add1=add=add2=0;
                stop_flag=0;
                position=1;
                hour1=0;
                min1=0;
                hourflag=minflag=index=0;
                main_flag=0;pri_flag=1;
                state=e_config_mode1;
                star=1;
                read1=0;
            }
            else if(state==e_viewevent)
            {
                state=e_config_mode1;
                read=0;
                index1=0;
                star=1;
            }
        }
        if(key==4)
        {
            CLEAR_DISP_SCREEN;
            if(state==e_config_mode||state==e_config_mode1)
            {
                state=e_config;
                star=1;
            }
            else if(state==e_config)
            {
                state=e_default_screen;
                blink=0;
                star=1;
            }
                else if(state==e_setevent)
                {
                position=1;
                state=e_config_mode1;
                star=1;
                read1=0;
               }
            else if(state==e_viewevent)
            {
                state=e_config_mode1;
                read=0;
                index1=0;
                star=1;
            }
            else if(state==e_settime)
            {
                position=1;
                hour=sec=min=0;
                state=e_config_mode;
                star=1;
            }
            else if(state==e_setdate)
            {
                position1=1;
                year=month=date1=0;
                state=e_config_mode;
                star=1;
            }
        }
        switch(state)
        {
            case e_default_screen:
                view_default_screen();
                break;
            case e_config:
                view_config();
                break;
            case e_config_mode:
                config_mode();
                break;
                case e_config_mode1:
                    view_config1();
                    break;
            case e_settime:
                set_time();
                break;
            case e_setdate:
                set_date();
                break;
            case e_setevent:
                set_event();
                break;
            case e_viewevent:
                view_event();
        }
	}
}