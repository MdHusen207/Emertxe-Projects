/*******************************************************************************************************************************************************************
*Title			: Subtraction
*Description		: This function performs subtraction of two given large numbers and store the result in the resultant list.
*Prototype		: int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*Input Parameters	: head1: Pointer to the first node of the first double linked list.
			: tail1: Pointer to the last node of the first double linked list.
			: head2: Pointer to the first node of the second double linked list.
			: tail2: Pointer to the last node of the second double linked list.
			: headR: Pointer to the first node of the resultant double linked list.
*Output			: Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"

/*int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
	printf("\nEntered in substraction\n");
	int c1,c2;
	c1=c2=1;
	Dlist*temp1=*head1,*temp2=*head2;
	while(temp1!=NULL||temp2!=NULL)
	{
		if(temp1!=NULL)
		{
			c1++;
			temp1=temp1->next;
		}
		if(temp2!=NULL)
		{
			c2++;
			temp2=temp2->next;
		}
	}
	if(c1!=c2)
	{
		if(c2>c1){
		temp1=*head1;
		*head1=*head2;
		*head2=temp1;
		temp2=*tail1;
		*tail1=*tail2;
		*tail2=temp2;
		}
	}
	else{
	while(temp1!=NULL||temp2!=NULL)
	{
		if(temp1->data);
	}
	}

	int d1,d2,b=0;
	while((*tail1) != NULL || (*tail2) != NULL )
	{
		if((*tail1)==NULL)
		d1=0;
		else
		d1=(*tail1)->data;

		if((*tail2)==NULL)
		d2=0;
		else
		d2=(*tail2)->data;
		
		printf("\n%d %d %d\n",d1,d2,b);
		int data;
		if(d1<(d2+b))
		{
			data=(d1+10)-(d2+b);
			if(b)
			b--;
			printf("%d\n",data);
			b++;
		}
		else
		{
			data=(d1-(d2+b));
			printf("%d\n",data);

			//b--;
		}

		dl_insert_first(headR, tailR, data);
		
		
		if((*tail1)!=NULL)
		(*tail1)=(*tail1)->prev;
		
		if((*tail2)!=NULL)
		(*tail2)=(*tail2)->prev;
	}
	if(c2>c1)
	dl_insert_first(headR, tailR, '-');

	printf_result(*headR);
}*/
int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, int sign1, int sign2)
{
	printf("\nEntered in substraction\n");
    int borrow = 0, carry = 0;

    if (sign1 == sign2)
    {
        int comp = compare_lists(*head1, *head2);
        if (comp >= 0) // head1 >= head2
        {
            subtract_lists(*tail1, *tail2, headR, &borrow);
            return sign1;
        }
        else // head1 < head2
        {
            subtract_lists(*tail2, *tail1, headR, &borrow);
            return -sign1; // rev sign
        }
    }
    else
    {
        add_lists(*tail1, *tail2, headR, &carry);
        return sign1; // Return sign
    }
}

