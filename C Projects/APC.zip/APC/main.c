/**************************************************************************************************************************************************************
*Title		: main function(Driver function)
*Description	: This function is used as the driver function for the all the functions
***************************************************************************************************************************************************************/


#include "apc.h"



int main(int argc, char *argv[])
{
    // Printing the argument count and the arguments
    printf("ARGC count--> %d\n", argc);
    for (int i = 0; i < argc; i++) {
        printf("Argv[%d]- %s  ", i, argv[i]);
    }

    if (argc != 4)
    {
        printf("Please give the input like: %s num1 operator/sign num2\n", argv[0]);
        return FAILURE;
    }

    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *headR = NULL, *tailR = NULL;
    
    char operator;
    int sign1 = 1, sign2 = 1;

    // Parsing the first number and sign
    if (argv[1][0] == '-')  
    {
        sign1 = -1;
        parse_number(&head1, &tail1, argv[1] + 1); // Skip'-' sign
    }
    else
    {
        parse_number(&head1, &tail1, argv[1]);      // Parsing the number to convert them to integer and store them 
    }

    operator = argv[2][0];

    if (argv[3][0] == '-')
    {
        sign2 = -1;
        parse_number(&head2, &tail2, argv[3] + 1); // Skip sign
    }
    else
    {
        parse_number(&head2, &tail2, argv[3]);      
    }
    
    int result_sign;
    switch (operator)
    {
        case '+':
            result_sign = addition(&head1, &tail1, &head2, &tail2, &headR, sign1, sign2);
            break;
        case '-':
            result_sign = subtraction(&head1, &tail1, &head2, &tail2, &headR, sign1, sign2);
            break;
        case 'x':
            result_sign = multiplication(&head1, &tail1, &head2, &tail2, &headR, sign1, sign2);
            break;
        case '/':
            result_sign = division(&head1, &tail1, &head2, &tail2, &headR, sign1, sign2);
            break;
        default:
            printf("Invalid Input: Try again...\n");
            return FAILURE;
    }

    // Print the result
    if(operator == '/'){
        printf("Quotient: ");
        print(headR, result_sign);

    }
    else{
        print_result(headR, result_sign);
    }

    return SUCCESS;
}

void parse_number(Dlist** head, Dlist** tail, const char* str)
{
    for (int i = 0; str[i] != '\0'; i++)
    {
        insert_at_end(head, tail, str[i] - '0'); // Converting char to integer and then inserting
    }
}

void print_result(Dlist* head, int sign)
{
    // Reverse the list before printing
    Dlist* prev = NULL;
    Dlist* current = head;
    Dlist* next = NULL;
    while (current != NULL)
    {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev;

    // Skip leading zeros
    while (head && head->data == 0)
    {
        head = head->next;
    }

    // case where result is zero
    if (!head)
    {
        printf("0\n");
        return;
    }

    if (sign == -1)
    {
        printf("-");
    }

    // Print the result
    Dlist* curr = head;
    while (curr)
    {
        printf("%d", curr->data);
        curr = curr->next;
    }
    printf("\n");
}

void print(Dlist *head, int sign){
    while(head){
        printf("%d",head->data);
        head = head->next;
    }
    printf("\n");
}