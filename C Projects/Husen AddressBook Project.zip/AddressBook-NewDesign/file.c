#include <stdio.h>
#include<string.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fp = fopen("file.csv","w");
    fprintf(fp,"%d\n",addressBook->contactCount);
    for(int n=0;n<addressBook->contactCount;n++)
    {
    	fprintf(fp,"%s,%s,%s\n",addressBook->contacts[n].name,addressBook->contacts[n].phone,addressBook->contacts[n].email);
    }
    fclose(fp);
}
void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fptr=fopen("file.csv","r");
    if(fptr==NULL)
    {
	printf("failed to open...\n");
	return;
    }
    int a;
    fscanf(fptr,"%d\n",&a);
    addressBook->contactCount=addressBook->contactCount+a;
    for(int m=0;m<addressBook->contactCount;m++)
    {
	fscanf(fptr,"%[^,],",addressBook->contacts[m].name);
	fscanf(fptr,"%[^,],",addressBook->contacts[m].phone);
	fscanf(fptr,"%[^\n]\n",addressBook->contacts[m].email);
    }

    
}
