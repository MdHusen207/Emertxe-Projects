#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
void del_cont(char *delTempCon,int i,AddressBook *addressBook)
{
    for(int k=i;k<addressBook->contactCount;k++)
    {
	addressBook->contacts[k]=addressBook->contacts[k+1];
    }
    addressBook->contactCount--;
    printf("Contact Deleted Successfull..");
}
int val_mail(char* search_temp_mail,AddressBook *addressBook,int flag)
{
    char waste='@';
    char* ValMail1=strchr(search_temp_mail,waste);
    if(ValMail1!=NULL);
    else
    {    printf("Invalid mail\n");
	return 0;
    }
    char validate_mail[19]=".com";
    char* ValMail2=strstr(search_temp_mail,validate_mail);
    if(ValMail2!=NULL);
    else
    {
	printf("Invlaid mail\n");
	return 0;
    }
    for(int k=0;k<addressBook->contactCount;k++)
    {
	int waste=strcmp(search_temp_mail,addressBook->contacts[k].email);
	if(waste!=0);
	else
	{
	    if(flag==0)
	    printf("Invalid mail\n");
	    return k+1;
	}
    }
    return -1;
}
int check_name(char *search_temp_name,AddressBook *addressBook)
{
    int i=0;
    do//while(i<(addressBook->contactCount))
    {
	int chk_name=strcmp(search_temp_name,addressBook->contacts[i].name);
	if(chk_name==0)
	{
	    printf("1.Name found\n");
	    return i;
	}
	else
	    i++;
    }while(i<(addressBook->contactCount));
	    printf("2.Name not found\n");
            return -1;
}
		
int val_phone(char *temp_number,AddressBook *addressBook,int flag)
{
    int c=0;
    for(int i=0;temp_number[i]!=0;i++)
    {
	if(temp_number[i]>='0'&&temp_number[i]<='9')
	    c++;
	else
	{
	    printf("1.Invalid number\n");
	    return 0;
	}
    }
    if(c!=10)
    {
	printf("1.Invalid number\n");
	return 0;
    }
    for(int k=0;k<(addressBook->contactCount);k++)
    {
	int ValNum=strcmp(temp_number,addressBook->contacts[k].phone);
	if(ValNum!=0);
	else
	{
	    if(flag==0)
	    printf("3.Invalid number\n");
	    return k+1;
	}
    }
    return -1;
}

void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria
    for(int i=0;i<addressBook->contactCount;i++)
    {
	printf("%3d-Name: %-18s\t",i+1,addressBook->contacts[i].name);
	printf("Phone: %-11s\t",addressBook->contacts[i].phone);
	printf("Mail: %-18s\t\n",addressBook->contacts[i].email);
    }
    
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

void createContact(AddressBook *addressBook,int i,int flagCrt)
{
	 //Define the logic to create a Contacts 
    char temp_name[30];
    printf("Enter the name:");
    getchar();
    scanf("%[^\n]",temp_name);
    getchar();
    char temp_number[11];
labelCreateNumber:printf("Enter the mobile number:");
    scanf("%s",temp_number);
    getchar();
    int createFlagPhone=0;
    int tphone=val_phone(temp_number,addressBook,createFlagPhone);
    if(tphone==-1);
    else
	goto labelCreateNumber;
    char temp_mail[30];
labelCreateMail:printf("Enter the mail:");
    scanf("%s",temp_mail);
    getchar();
    int createFlagMail=0;
    int tmail=val_mail(temp_mail,addressBook,createFlagMail);
    if(tmail==-1);
    else
	goto labelCreateMail;
    if(flagCrt==0)
    {
    strcpy(addressBook->contacts[addressBook->contactCount].name,temp_name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone,temp_number);
    strcpy(addressBook->contacts[addressBook->contactCount].email,temp_mail);
    addressBook->contactCount++;
    }
    else
    {
    strcpy(addressBook->contacts[i].name,temp_name);
    strcpy(addressBook->contacts[i].phone,temp_number);
    strcpy(addressBook->contacts[i].email,temp_mail);
    }
    
}

void searchContact(AddressBook *addressBook) 
{
    
    printf("Enter your choice from which you want to search:");
    printf("\n1.Name\n2.Phone\n3.Email\n");
    int choice;
    char search_temp_name[30];
    char search_temp_phone[11];
    char search_temp_email[25];
    scanf("%d",&choice);
    getchar();
    switch(choice)
    {
	case 1:
labelSearchName: printf("Enter the name:");
	    scanf(" %[^\n]",search_temp_name);
	    getchar();
	    int stname=check_name(search_temp_name,addressBook);
	    if(stname==-1)
		goto labelSearchName;
	    else
	    {
		printf("1.Name:%s\n",addressBook->contacts[stname].name);
	        printf("2.Phone:%s\n",addressBook->contacts[stname].phone);
		printf("3.Email:%s\n",addressBook->contacts[stname].email);
	    }
	    break;
	case 2:
labelSearchPhone:  printf("Enter the phone:");
	    scanf("%s",search_temp_phone);
	    getchar();
	    int searchFlagPhone=1;
	    int stphone=val_phone(search_temp_phone,addressBook,searchFlagPhone);
	    if(stphone<=0)
	    {
		printf("Invlaid number\n");
		goto labelSearchPhone;
	    }
	    else
	    {
		printf("%s\n",addressBook->contacts[stphone-1].name);
		printf("%s\n",addressBook->contacts[stphone-1].phone);
		printf("%s\n",addressBook->contacts[stphone-1].email);
	    }
	    break;
	case 3:
labelSearchMail: printf("Enter the email:");
	    scanf("%s",search_temp_email);
	    getchar();
	    int searchFlagMail=1;
	    int stmail=val_mail(search_temp_email,addressBook,searchFlagMail);
	    if(stmail<=0)
	    {
		printf("Invalid mail\n");
		goto labelSearchMail;
	    }
	    else
	    {
		printf("%s\n",addressBook->contacts[stmail-1].name);
		printf("%s\n",addressBook->contacts[stmail-1].phone);
		printf("%s\n",addressBook->contacts[stmail-1].email);
	    }

	    break;
    }

}

void editContact(AddressBook *addressBook)
{
	// Define the logic for Editcontact 
    int Echoice;
labelEditChoice:printf("Enter the choice by which you want to edit\n1.Name:\n2.Phone:\n3.Email\n");
    scanf("%d",&Echoice);
    char str1[30];
    getchar();
    char str2[11];
    char str3[25];
    switch(Echoice)
    {
	case 1:
labelEditName:printf("Enter the name:");
       char edit_temp_name[30];
       scanf(" %[^\n]",edit_temp_name);
       	    int edFlag=1;
            int edname=check_name(edit_temp_name,addressBook);
	    if(edname==-1){
		printf("Contact not found\n");
                goto labelEditName;}
	    else
	    {
		printf("Conctact found...\nEnter the new details\n");
		createContact(addressBook,edname,edFlag=1);
	    }
	    break;
	case 2:
labelEditPhone:printf("Enter the number:");
        char edit_temp_phone[11];
	scanf("%s",edit_temp_phone);
	int editFlagPhone=1;
	int edphone=val_phone(edit_temp_phone,addressBook,editFlagPhone);
	if(edphone<=0){
	    printf("Contact not found\n");
	    goto labelEditPhone;}
	else
	{
	    printf("Contact found...\nEnter the new details\n");
	    createContact(addressBook,edphone-1,editFlagPhone);
	}
	    break;
	case 3:
labelEditMail:printf("Enter the mail:");
	char edit_temp_mail[25];
        scanf("%s",edit_temp_mail);
	int editFlagMail=1;
	int edmail=val_mail(edit_temp_mail,addressBook,editFlagMail);
	if(edmail<=0){
	    printf("Contact not found\n"); 
    	    goto labelEditMail;}
	else
	{
	    printf("Contact found...\nEnter the new details\n");
    	    createContact(addressBook,edmail-1,editFlagMail);
	}
	    break;
	default:
	    printf("Invalid Choice:\n");
	    goto labelEditChoice;
	}
    
}

void deleteContact(AddressBook *addressBook)
{
	// Define the logic for deletecontact 
    int delChoice;
labelDeleteChoice:printf("Enter the choice to search the contact to be deleted\n1.Name\n2.Phone\n3.email\n");
    scanf("%d",&delChoice);
    char delTempStr[30];
    getchar();
    switch(delChoice)
    {
	case 1:
labelDelName:printf("Enter the name:");
	     scanf(" %[^\n]",delTempStr);
	     int delName=check_name(delTempStr,addressBook);
	     if(delName==-1)
	     	goto labelDelName;
	     else
		 del_cont(delTempStr,delName,addressBook);
	     break;
	case 2:
labelDelPhone:printf("Enter the phone:");
	     scanf("%s",delTempStr);
	     int delFlag1=1;
	     int delPhone=val_phone(delTempStr,addressBook,delFlag1);
	     if(delPhone<=0){
		 printf("Contact not found\n");
		 goto labelDelPhone;}
	     else
		del_cont(delTempStr,delPhone-1,addressBook);
	    break;
	case 3:
labelDelEmail:printf("Enter the mail:");
	     scanf("%s",delTempStr);
	     int delFlag2=1;
	     int delEmail=val_mail(delTempStr,addressBook,delFlag2);
	     if(delEmail<=0){
		 printf("Contact not found\n");
		goto labelDelEmail;}
	     else
		del_cont(delTempStr,delEmail-1,addressBook);
	     break;
	default:
	     printf("Invalid Choice\n");
	     goto labelDeleteChoice;
    }
}
            
    

