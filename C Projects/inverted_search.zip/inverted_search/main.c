#include "inv.h"

void print_list(f_list *head) 
{
    printf("Head -> ");
    while (head) 
    {
        printf("%s", head->str);
        if (head->link) printf(" -> ");
        head = head->link;
    }
    printf(" -> Tail\n");
}

void create_HT(hash_t *HT, int size)
{
    for(int i=0;i<size;i++)
    {
        HT[i].index=i;
        HT[i].link=NULL;
    }
}

int main(int argc,char *argv[])
{
    int option,create_flag=0,update_flag=0,file_flag=0;
    //f_list *update_head=NULL;
    f_list *head=NULL;
    for(int i=1;i<argc;i++)
    {
       validate(&head,argv[i]);
    }
    
    print_list(head); 

    hash_t arr[28];
    create_HT(arr,28);


    do
    {
        printf("1.Create Database\n2.Search Database\n3.Update Database\n4.Display Database\n5.Save to Data File\n6.Exit\n");
        printf("Enter you choice:");
        scanf("%d",&option);

        switch(option)
        {
            case 1:
            if(create_flag==0)
            {
                // if(update_flag==1)
                // goto Validate_again;
                // Come_again:
                if(create_DB(arr,head)==SUCCESS)
                {
                    printf("Database created successfully\n");
                    create_flag=1;
                }
                else
                {
                    if(file_flag==1)
                    printf("INFO: Due to the SAME FILE passed that already being updated in the hash table\n");
                    printf("Hence Failed to create Database\n");
                }
            }
            else
            {
                printf("INFO: Hash table is already created...\n");
            }
            break;
            case 2:
            char find_word[50];
            printf("Enter Word to be searched: ");
            scanf("%s", find_word);
            if (search_data(arr, find_word) == FAILURE) 
            printf("Word not found in database.\n");
            break;
            case 3:
            if(create_flag==0&&update_flag==0)
            {
            printf("Enter the backup file:\n");
            char backup_file[30];
            scanf("%s",backup_file);
            if(update_DB(arr,&head,backup_file)==SUCCESS)
            {
                printf("Database updated successfully\n");
                update_flag++;
                file_flag=1;
            }
            else
            printf("Database update FAILURE\n");
            }
            else
            printf("ERROR: Hash table is already created...\n");
            //print_list(head);
            break;
            case 4:
            display_database(arr);
            break;
            case 5:
            FILE *bptr;
            bptr=fopen("backup.txt","w");
            if(bptr==NULL){
            printf("FAILED TO OPEN\n");
            return 1;
            }
            if(save_DB(arr,bptr)==SUCCESS)
            printf("Database saved successfully\n");
            fclose(bptr);
            break;
            case 6:
            printf("came out\n");
            break;            
        }
    }while(option!=6);
}
