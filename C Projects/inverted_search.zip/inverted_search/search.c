#include "inv.h"
int search_data(hash_t arr[], char *find_word)
{
    printf("Entered in search the word is %s\n",find_word);
    int ind,i=0;
    if(find_word[i]>=65 && find_word[i]<=90)
    ind=find_word[i]-65;
    else if(find_word[i]>=97 && find_word[i]<=122)
    ind=find_word[i]-97;
    else if(find_word[i]>=48 && find_word[i]<=57)
    ind=26;
    else
    ind=27;
    printf("Index is %d\n",ind);
    main_node *main_temp = arr[ind].link;
    while (main_temp!=NULL) 
    {
        printf("double in\n");
        if(strcmp(main_temp->word,find_word)==0)
        {
            printf("The word [%s] ", main_temp->word);
            printf("Is present in total %-2d file \n", main_temp->f_count);
            sub_node *sub_temp = main_temp->sub_link;
            while (sub_temp)
            {
                printf("In file: %s ", sub_temp->f_name);  
                printf("With word count: %d  ", sub_temp->w_count);  
                printf("\n");
                sub_temp = sub_temp->link;
            }
            if(sub_temp==NULL)
            return SUCCESS;
            printf("\n");
        }
        main_temp = main_temp->main_link;
    }
    if(main_temp==NULL)
    return FAILURE;
}