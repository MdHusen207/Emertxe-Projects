#ifndef INV_H

#define INV_H 

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define LIST_EMPTY -2
#define DATA_NOT_FOUND -3

typedef struct SUB_NODE
{
    char f_name[100];
    int w_count;
    struct SUB_NODE *link;
}sub_node;

typedef struct MAIN_NODE
{
    char word[100];
    struct MAIN_NODE *main_link;
    int f_count;
    sub_node *sub_link;
}main_node;

typedef struct node
{
    int index;
    main_node *link;
}hash_t;

typedef struct F_list
{
    char str[30];
    struct F_list *link;
}f_list;

void validate(f_list **head, char *argv);

int create_DB(hash_t *arr,f_list *head);

void display_database(hash_t arr[]);

int search_data(hash_t arr[], char *find_word);

int save_DB(hash_t *arr,FILE *bptr);

int update_DB(hash_t *arr, f_list **head,char backup_file[]);

int delete_filename(f_list **head, char *file_name);

#endif