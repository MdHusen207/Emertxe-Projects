#include "inv.h"

int save_DB(hash_t *arr,FILE *bptr)
{
    printf("Entered in save\n");
    for(int i=0;i<=27;i++)
    {
        if(arr[i].link!=NULL)
        {
            main_node *main_temp=arr[i].link;
            while(main_temp!=NULL)
            {
                fprintf(bptr,"#;%d;",i);
                fprintf(bptr,"%s;",main_temp->word);
                fprintf(bptr,"%d;",main_temp->f_count);
                sub_node *sub_temp=main_temp->sub_link;
                while(sub_temp!=NULL)
                {
                    printf("%s\n",sub_temp->f_name);
                    fprintf(bptr,"%s;",sub_temp->f_name);
                    fprintf(bptr,"%d;",sub_temp->w_count);
                    sub_temp=sub_temp->link;
                }
                fprintf(bptr,"#\n");
                main_temp=main_temp->main_link;
            }
        }
    }
}