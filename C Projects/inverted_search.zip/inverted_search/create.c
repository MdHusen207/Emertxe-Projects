#include "inv.h"

int create_DB(hash_t *arr,f_list *head)
{
    if(head == NULL)
    return FAILURE;
    printf("Entered in create Database\n");
    f_list *flist_temp=head;
    while(flist_temp!=NULL)
    {
        FILE *file;
        char fname[30];
        strcpy(fname,flist_temp->str);
        //printf("In file %s\n",fname);
        file=fopen(fname,"r");
        if(file==NULL)
        return FAILURE;
        char load_word[50];
        //printf("return from open is not null\n");
        
        while((fscanf(file,"%s",load_word))!=EOF)
        {
            int ind,i=0;
            if(load_word[i]>=65 && load_word[i]<=90)
            ind=load_word[i]-65;
            else if(load_word[i]>=97 && load_word[i]<=122)
            ind=load_word[i]-97;
            else if(load_word[i]>=48 && load_word[i]<=57)
            ind=26;
            else
            ind=27;
            //printf("%s",load_word);
            main_node *new_main=malloc(sizeof(main_node));
            new_main->main_link=NULL;
            new_main->sub_link=NULL;
            new_main->f_count=1;
            sub_node *new_sub=malloc(sizeof(sub_node));
            new_sub->link=NULL;
            new_sub->w_count=1;
        
            if(arr[ind].link==NULL)
            {
                arr[ind].link=new_main;
                strcpy(new_main->word,load_word);
                new_main->sub_link=new_sub;
                strcpy(new_sub->f_name,fname);
                goto next;
            }
            main_node *main_temp=arr[ind].link;
            while(main_temp!=NULL)
            {
                if(strcmp(main_temp->word,load_word)==0)
                {
                    sub_node *sub_temp;
                    sub_temp=main_temp->sub_link;
                    while(sub_temp!=NULL)
                    {
                        if(strcmp(sub_temp->f_name,fname)==0)
                        {
                            sub_temp->w_count++;
                            goto next;
                        }
                        if(sub_temp->link!=NULL)
                        sub_temp=sub_temp->link;
                        else
                        break;
                    }
                    strcpy(new_sub->f_name,fname);
                    main_temp->f_count++;
                    sub_temp->link=new_sub;
                    //new_sub->link=NULL;
                    goto next;
                }
                if(main_temp->main_link!=NULL)
                main_temp=main_temp->main_link;
                else
                break;
            }
            new_main->sub_link=new_sub;
            strcpy(new_sub->f_name,fname);
            main_temp->main_link=new_main; 
            strcpy(new_main->word,load_word);  
            //new_main->main_link=NULL;
            next:
        }
      flist_temp=flist_temp->link;
    }
}

