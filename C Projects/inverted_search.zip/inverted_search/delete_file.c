#include "inv.h"

int delete_filename(f_list **head, char *file_name) 
{
    f_list *temp = *head;
    f_list *prev = NULL;
    while (temp) 
    {
        if (strcmp(temp->str, file_name) == 0) 
        {
            if (temp == *head) 
            {
                *head = temp->link; // If the file to delete is the head, update the head
                free(temp);
            } else 
            {
                prev->link = temp->link; 
                free(temp);
            }
        }
        prev = temp;
        temp = temp->link;
    }
}