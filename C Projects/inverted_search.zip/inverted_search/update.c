#include "inv.h"
int update_DB(hash_t arr[], f_list **head,char *file)
{
    if(strstr(file,".txt")!=NULL)
    {
    for(int i=0;file[i]!=0;i++)
    {
        if(file[i]=='.')
        if(strlen(file+i)!=4)
        {
            printf("Due to file extension\n");
            return FAILURE;
        }
    }
    }
    else
    {
        printf("Due to file is not txt\n");
        return FAILURE;
    }
    
    FILE *bptr;
    bptr=fopen(file,"r");
    if(bptr==NULL)
    {
        printf("Due to file is NULL\n");
        return FAILURE;
    }
    fseek(bptr,0,SEEK_SET);
    char c;
    c=getc(bptr);
    if(c!='#')
    {
        printf("Due to the line not strating with #\n");
        return FAILURE;
    }
    rewind(bptr);
    int ind;
    sub_node *prev_node;
    while(fscanf(bptr,"#;%d;",&ind)!=EOF)
    {
        // fscanf(bptr,"#;");
        // fscanf(bptr,"%d",&ind);
        // printf("The index value is %d\n",ind);
        main_node *temp;
        if(arr[ind].link!=NULL)
        {
            temp=arr[ind].link;
            while(temp->main_link!=NULL)
            {
                temp=temp->main_link;
            }
        }
        main_node *new_main=malloc(sizeof(main_node));
        new_main->main_link=NULL;
        new_main->sub_link=NULL;
        if(arr[ind].link)
        temp->main_link=new_main;
        else
        arr[ind].link=new_main;

        fscanf(bptr,"%[^;];%d;",new_main->word,&new_main->f_count);

        for(int i=1;i<=new_main->f_count;i++)
        {
            sub_node *new_sub=malloc(sizeof(sub_node));
            new_sub->link=NULL;
            fscanf(bptr,"%[^;];%d;",new_sub->f_name,&new_sub->w_count);
            delete_filename(head, new_sub->f_name);
            
            if(i==1)
            {
                prev_node=new_sub;
                new_main->sub_link=new_sub;
            }
            else
            {
            prev_node->link=new_sub;
            prev_node=prev_node->link;
            }
        }
        fscanf(bptr,"#\n");
    }  
    return SUCCESS; 
}

