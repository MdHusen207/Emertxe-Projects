#include "inv.h"

void validate(f_list **head, char *argv)
{
    int f=0;
    if(strstr(argv,".txt")!=NULL)
    {
        //printf("Entered after .txt\n");
        for(int j=0;argv[j]!=0;j++)
        {
            if(argv[j]=='.')
            {
                int l=strlen(argv+j);
                if(l==4)
                {
                    FILE *fptr;
                    fptr=fopen(argv,"r");
                    if(fptr!=NULL)
                    {
                        fseek(fptr,0,SEEK_END);
                        int fsize=ftell(fptr);
                        //printf("The file size is %d\n",fsize);
                        if(fsize!=0)
                        {
                            f_list*new=malloc(sizeof(f_list));
                            if(*head==NULL)
                            {
                                strcpy(new->str,argv);
                                //new->str=argv[i];
                                //printf("it is %s",new->str);
                                new->link=NULL;
                                *head=new;
                            }
                            else
                            {
                                f_list*temp=*head;
                                while(temp->link!=NULL)
                                {
                                    if(strcmp(temp->str,argv)==0)
                                    f++;
                                    temp=temp->link;
                                }
                                if(f)
                                {
                                    printf("ERROR: Entered file %s is repeated\n",argv);
                                    break;
                                }
                                else
                                {
                                    strcpy(new->str,argv);
                                    printf("Successful : File %s is added into the list",argv);
                                    new->link=NULL;
                                    temp->link=new;
                                }
                            }
                        }
                        else
                        {
                            printf("ERROR: Entered file %s is empty file\n",argv);
                            break;
                        }
                    }
                    else
                    printf("ERROR: Entered file %s does not exist\n",argv);
                }
                else
                printf("ERROR: Entered file %s dont have propper extension\n",argv);
            }
        }
    }
    else
    printf("ERROR: Please pass FILE with propper Extension\n");
}