#include"inv.h"

void display_database(hash_t hash_arr[]) 
{
    // Print the header for the hash table output
    printf("[index]  [word]  file_count file/s File:file_name word_count\n");
    printf("\n");
    int flag=0;
    for (int i = 0; i <= 27; i++) 
    {
        if (hash_arr[i].link != NULL) 
        {
            flag=1;
            main_node *temp = hash_arr[i].link;

            // Iterate through the linked list at this index
            while (temp) 
            {
                printf("[%-2d] ", i);
                printf("    [ %-10s ]   ", temp->word);
                printf(" %-2d file/s:", temp->f_count);
                sub_node *temp_sub = temp->sub_link;
                while (temp_sub) 
                {
                    printf(" %-10s", temp_sub->f_name);  
                    printf(" %-3d  ", temp_sub->w_count);  
                    temp_sub = temp_sub->link;
                }
                temp = temp->main_link;
                printf("\n");
            }
       }
    }
    if(flag==0)
    printf("Tabel is EMPTY, nothing to print\n");
}

