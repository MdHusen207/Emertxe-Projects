#ifndef DECODE_H
#define DECODE_H

#include "types.h"

typedef struct _DecodeInfo
{
    char stego_image_fname[20];
    FILE *fptr_stego_image;
    char output_file_fname[20];
    FILE *fptr_out_file;
}DecodeInfo;


// Function to open the stego image file
Status open_files_stego(DecodeInfo *decInfo);

//read and validation 
Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *dncinfo);
// Function to skip the BMP header
Status skip_header_bmp(DecodeInfo *decInfo);

// Function to get the size of the magic string from the image
int find_string_size(DecodeInfo *decInfo);

// Function to extract a hidden string of a given size from the image
char *find_string(char *string,int size, FILE *fptr);

// Function to perform the entire decoding process
Status do_decoding(DecodeInfo *decInfo);

#endif 


