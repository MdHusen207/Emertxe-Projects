/*
Mohammad Husen
roll:9

*/#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>
#include<stdlib.h>

Status validbmp(char* str) 
{
    int len=0, flag=0;
    for(int i=0; str[i] != 0; i++) 
    {
        if(str[i] == '.') 
        {
            flag = 1;
        }
        if(flag == 1) 
        {
            len=len+1;
        }
    }
    if(len == 4) 
        return e_success;
    else
        return e_failure;
}

Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo) 
{
    if(argc >= 3 && argc <= 4) 
    {
        if(strstr(argv[2], ".bmp")) 
        {
            if(validbmp(argv[2]) == e_success) 
            {
                strcpy(decInfo->stego_image_fname , argv[2]);
                if(argv[3] == NULL) 
                {
                    strcpy(decInfo->output_file_fname, "output");
                    printf("INFO: Output File not Mentioned. Creating  as Default\n");
                    return e_success;
                } 
                else 
                {
                    strcpy(decInfo->output_file_fname, argv[3]);
                    return e_success;
                }
            } 
            else 
            {
                 printf("/lsb_steg: Decoding /lsb_stegd bmp file> [output file]\n");
                return e_failure;
            }
        } 
        else 
        {
             printf("/lsb_steg: Decoding /lsb_stegd bmp file> [output file]\n");
            return e_failure;
        }
    } 
    else 
    {
        printf("Error: Insufficient arguments...\n");
        return e_failure;
    }
}

Status read_and_validate_encode_args(int argc, char *argv[], EncodeInfo *encInfo) 
{
    if(argc >= 4 && argc <= 5) 
    {
        if(strstr(argv[2], ".bmp")) 
        {
            if(validbmp(argv[2]) == e_success) 
            {
                strcpy(encInfo->src_image_fname , argv[2]);
                if(strstr(argv[3], ".txt")) 
                {
                    strcpy(encInfo->secret_fname , argv[3]);
                    if(argv[4] != NULL) 
                    {
                        if(strstr(argv[4], ".bmp")) 
                        {
                            strcpy(encInfo->stego_image_fname ,argv[4]);
                            return e_success;
                        } 
                        else 
                        {
                             printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
                            return e_failure;
                        }
                    } 
                    else 
                    {
                        printf("INFO: Output File not mentioned. Creating stego_img.bmp as default\n");
                        strcpy(encInfo->stego_image_fname ,"stego_img.bmp");
                        return e_success;
                    }
                } 
                else 
                {
                     printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
                    return e_failure;
                }
            } else 
            {
                 printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
                return e_failure;
            }
        } else 
        {
           printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
            return e_failure;
        }
    } else 
    {
        printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
        return e_failure;
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2) 
    {
        printf("/lsb_steg: Encoding: /lsb_stege bmp file> < txt file> [output file]\n");
        printf("/lsb_steg: Decoding /lsb_stegd bmp file> [output file]\n");
        return e_failure;
    }

    EncodeInfo encInfo;
    DecodeInfo decInfo;
    unsigned int img_size;

    if (argc == 1) 
    {
        printf("Error: insufficient arguments\n");
    } 
    else 
    {
        int ret = (strcmp(argv[1], "-e"));
        if (ret == 0) 
        {
            if (read_and_validate_encode_args(argc, argv, &encInfo) == e_success) 
            {
                printf("INFO: opening required files\n");
                if (open_files(&encInfo) == e_failure) 
                {
                    printf("ERROR: %s function failed\n", "open_files");
                    return 1;
                } 
                else 
                {
                    printf("INFO: Encoding procedure started ##\n");
                    if (do_encoding(&encInfo) == e_success) 
                    {
                        printf("INFO: ##Encoding Done Successfully ##\n");
                        fclose(encInfo.fptr_src_image);
                        fclose(encInfo.fptr_stego_image);
                    } 
                    else 
                    {
                        printf("not encoded\n");
                    }
                }
            }
        } 
        else if (strcmp(argv[1], "-d") == 0) 
        {
            printf("INFO: ##Decoding Procedure Started ##\n");
            if (read_and_validate_decode_args(argc, argv, &decInfo) == e_success) 
            {
                printf("INFO: Opening required files\n");
                if (open_files_stego(&decInfo) == e_failure) 
                {
                    printf("ERROR: %s function failed\n", "open_files");
                    return 1;
                } 
                else 
                {
                    printf("INFO: Done\n");
                    if (do_decoding(&decInfo) == e_success) 
                    {
                        printf("sfdsf");
                        printf("INFO: ##Decoding Done Successfully ##\n");
                        fclose(decInfo.fptr_stego_image);
                    } 
                    else 
                    {
                        printf("not decoded\n");
                    }
                }
            }
        } else 
        {
             printf("/lsb_steg: Decoding /lsb_stegd bmp file> [output file]\n");
            return e_failure;
        }
    }

    return 0;
}
