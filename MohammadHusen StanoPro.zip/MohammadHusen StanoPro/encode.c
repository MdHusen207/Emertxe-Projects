/*
Mohammad Husen
roll:9
24018_293
24018B
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "encode.h"
#include "types.h"

/* Function Definitions */

/* Get image size */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    fseek(fptr_image, 18, SEEK_SET);

    fread(&width, sizeof(int), 1, fptr_image);
    fread(&height, sizeof(int), 1, fptr_image);

    return width * height * 3;
}

/* Get File pointers for input/output files */
Status open_files(EncodeInfo *encInfo)
{
    printf("Entered in open file for encoding...");
    printf("INFO: Opening required files\n");

    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->src_image_fname);

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->secret_fname);

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->stego_image_fname);

    return e_success;
}

/* Copy the BMP header from source to stego image */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_stego_image)
{
    printf("INFO: Copying Image Header\n");
    char header[54];
    rewind(fptr_src_image);
    rewind(fptr_stego_image);
    fread(header, 54, 1, fptr_src_image);  // Read the BMP header from the source image
    fwrite(header, 54, 1, fptr_stego_image);  // Write the BMP header to the stego image
    printf("INFO: Done\n");
    return e_success;
}

/* Check if the image has enough capacity */
Status check_capacity(EncodeInfo *encInfo)
{
    printf("INFO: Check ing for %s size\n", encInfo->secret_fname);
    int src_image_size = get_file_size(encInfo->fptr_src_image);
    int sec_file_size = get_file_size(encInfo->fptr_secret);
    
    if (sec_file_size == 0)
    {
        printf("INFO: Done.Empty\n");
        return e_failure;
    }
    printf("INFO: Done. Not Empty\n");

    char magic_string[20];
    printf("Enter the magic_string: ");
    scanf("%s", magic_string);
    printf("Bfr:%s",magic_string);
    strcpy(encInfo->magic_str, magic_string);
    int len_magic = strlen(magic_string);

    char *ext_str = strchr(encInfo->secret_fname, '.');
    int len_ext = strlen(ext_str);

    printf("INFO: Checking for %s capacity to handle %s\n", encInfo->src_image_fname, encInfo->secret_fname);
    if (src_image_size >= 54 + 32 + 32 + 32 + (sec_file_size * 8) + (len_magic * 8) + (len_ext * 8))
    {
        printf("INFO: Done. Found OK\n");
        return e_success;
    }
    else
    {
        printf("INFO: Done. Not enough capacity\n");
        return e_failure;
    }
}
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    int file_size = ftell(fptr);
    rewind(fptr);
    return file_size;
}

/* Perform encoding */
Status do_encoding(EncodeInfo *encInfo)
{
    printf("INFO: ## Encoding Procedure Started # #\n");

    if (check_capacity(encInfo) == e_success)
    {
        printf("1..");
        if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
        {
            printf("2...");
            if (encode_magic_string(encInfo->magic_str, encInfo) == e_success)
            {
                printf("3...");
                printf("INFO: Encoding Magic String Signature\nINFO: Done\n");
                char *file_extn = strchr(encInfo->secret_fname, '.');
                if (encode_secret_file_extn(file_extn, encInfo) == e_success)
                {
                    printf("4...");
                    printf("INFO: Encoding %s File Extension\nINFO: Done\n", encInfo->secret_fname);

                    int sec_file_size = get_file_size(encInfo->fptr_secret);
                    if (encode_secret_file_size(sec_file_size, encInfo) == e_success)
                    {
                        printf("INFO: Encoding %s File Size\nINFO: Done\n", encInfo->secret_fname);

                        if (encode_secret_file_data(encInfo) == e_success)
                        {
                            printf("INFO: Encoding %s File Data\nINFO: Done\n", encInfo->secret_fname);
                            copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image);
                            printf("INFO: Copying Left Over Data\nINFO: Done\n");
                        }
                        else
                        {
                            printf("Failed to Encode secret message.\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("Failed to Encode secret file size.\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("Failed to Encode file extension.\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Failed to Encode magic string.\n");
                return e_failure;
            }
        }
        else
        {
            printf("Failed to copy BMP header.\n");
            return e_failure;
        }
    }
    else
    {
        printf("INFO: Insufficient capacity.\n");
        return e_failure;
    }

    return e_success;
}

/* Encode magic string */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    int len = strlen(magic_string);
    if (encode_size_to_lsb(len, encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
    {
        return encode_data_to_image((char *)magic_string, len, encInfo->fptr_src_image, encInfo->fptr_stego_image);
    }
    return e_failure;
}

/* Encode size to LSB */
Status encode_size_to_lsb(int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer[32];
    fread(buffer, 32, 1, fptr_src_image);
    char bit;

    for (int i = 0; i < 32; i++)
    {
        buffer[i]=buffer[i]&~(1);
        bit=size&(1 << i);
        bit=bit>>i;
        buffer[i]=buffer[i]|bit;
    }

    fwrite(buffer, 32, 1, fptr_stego_image);
    return e_success;
}

/* Encode data to image */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer[8];
    char temp;
    for (int i = 0; i < size; i++)
    {
        fread(buffer, 8, 1, fptr_src_image);

        for (int j = 0; j < 8; j++)
        {
            buffer[j] = buffer[j] & ~(1);
            temp = data[i] & (1 << j);
            temp = temp >> j;
            buffer[j] = buffer[j] | temp;
        }

        fwrite(buffer, 8, 1, fptr_stego_image);
    }

    return e_success;
}

/* Encode file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    int len = strlen(file_extn);
    if (encode_size_to_lsb(len, encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
    {
        return encode_data_to_image((char *)file_extn, len, encInfo->fptr_src_image, encInfo->fptr_stego_image);
    }
    return e_failure;
}

/* Encode secret file size */
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo)
{
    return encode_size_to_lsb(file_size, encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

/* Encode secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    printf("in...");
    int sec_file_size = get_file_size(encInfo->fptr_secret);
    char data[sec_file_size];

    fread(data, sec_file_size, 1, encInfo->fptr_secret);
    return encode_data_to_image(data, sec_file_size, encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

/* Copy remaining image data */
Status copy_remaining_img_data(FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer;
    while (fread(&buffer, 1, 1, fptr_src_image))
    {
        fwrite(&buffer, 1, 1, fptr_stego_image);
    }
    return e_success;
}

