/*
Name:Mohammad Husen

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decode.h"
#include "types.h"

Status open_files_stego(DecodeInfo *decInfo)
{
    printf("INFO: Opening required files\n");

    FILE *fptr = fopen(decInfo->stego_image_fname, "rb");

    if (fptr != NULL)
    {
        printf("INFO: Opened %s\n", decInfo->stego_image_fname);
        decInfo->fptr_stego_image = fptr;
    }
    else
    {
        printf("ERROR: Stego file could not be opened\n");
        return e_failure;
    }

    return e_success;
}

Status skip_header_bmp(DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);
    return e_success;
}

int find_string_size(DecodeInfo *decInfo)
{
    char buffer[32];
    fread(buffer, 32, 1, decInfo->fptr_stego_image);
    int len = 0, get;
    for (int i = 0; i < 32; i++)
    {
        get = (buffer[i] & (1)) << i;
        len |= get;
    }
    return len;
}

char *find_string(char *string, int size, FILE *fptr)
{
    char buffer[8];
    char ch = 0, get;
    for (int i = 0; i < size; i++)
    {
        fread(buffer, 8, 1, fptr);
        for (int j = 0; j < 8; j++)
        {
            get = (buffer[j] & (1)) << j;
            ch |= get;
        }
        string[i] = ch;
        ch = 0;
    }
    string[size] = '\0';
}

Status do_decoding(DecodeInfo *decInfo)
{
    printf("INFO: ## Decoding Procedure Started... ##\n");

    // Skip the BMP header
    skip_header_bmp(decInfo);

    // Extract the length of the magic string
    printf("INFO: Decoding Magic String Signature\n");
    int magic_len = find_string_size(decInfo);
    printf("INFO: Done\n");

    // Extract the magic string
    char magic_str[30];
    find_string(magic_str, magic_len, decInfo->fptr_stego_image);

    // Get user input for password
    char user_magic[20];
    printf("ENTER PASSWORD: ");
    scanf("%s", user_magic);

    // Compare user input with the magic string
    if (strcmp(magic_str, user_magic) == 0)
    {
        printf("INFO: Correct password\n");

        // Extract the length of the extension string
        printf("INFO: Decoding Output File Extension\n");
        int exn_len = find_string_size(decInfo);
        printf("Magic size %d",exn_len);
        printf("INFO: Done\n");

        // Extract the extension string
        char exn_str[30];
        find_string(exn_str, exn_len, decInfo->fptr_stego_image);

        // If no output file name is provided, create a default one
        if (strlen(decInfo->output_file_fname) == 0)
        {
            strcpy(decInfo->output_file_fname, "decoded.txt");
            printf("INFO: Output File not mentioned. Creating decoded.txt as default\n");
        }

        // Concatenate the extension to the file name
        strcat(decInfo->output_file_fname, exn_str);
        printf("Concat after");

        // Open the output file
        decInfo->fptr_out_file = fopen(decInfo->output_file_fname, "w");
        if (decInfo->fptr_out_file == NULL)
        {
            printf("ERROR: Failed to open output file\n");
            return e_failure;
        }
        printf("INFO: Opened %s\n", decInfo->output_file_fname);

        // Extract the length of the secret data
        printf("INFO: Decoding %s File Size\n", decInfo->output_file_fname);
        int sec_len = find_string_size(decInfo);
        printf("%d",sec_len);
        printf("INFO: Done\n");

        // Extract the secret data
        printf("INFO: Decoding %s File Data\n", decInfo->output_file_fname);
        char sec_str[sec_len + 1]; // Allocate memory based on the secret data size
        find_string(sec_str, sec_len, decInfo->fptr_stego_image);
        printf("INFO: Done\n");

        // Write the secret data to the output file
        fwrite(sec_str, sec_len, 1, decInfo->fptr_out_file);
        fclose(decInfo->fptr_out_file);

        printf("Secret data decoded ->to %s\n", decInfo->output_file_fname);
    }
    else
    {
        printf("ERROR: Incorrect password\n");
        return e_failure;
    }

    return e_success;
}

