#include <xc.h>
#include "external_eeprom.h"
#include "main.h"

void event_reader()
{
    //waste=read_ex_eeprom(add);
    //clcd_print(waste,LINE1(0));
    r_add=0x00;
    if(ec>10)
        r_add=((ec%10)*12);
    for(r_i=0;(r_i<((ec<10)?ec:10));r_i++)
    {
        if(r_add==120)
            r_add=0x00;
        for(r_j=0;r_j<16;r_j++)
        {
            if(r_j==8||r_j==9||r_j==12||r_j==13)
                ev_list[r_i][r_j]=' ';
            else if(r_j==14||r_j==15)
                ev_list[r_i][r_j] = read_ex_eeprom(r_add++)+'0';
            else
                ev_list[r_i][r_j] = read_ex_eeprom(r_add++);
        }
    }
}