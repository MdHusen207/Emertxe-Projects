#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "adc.h"
#include "matrix_keypad.h"
#include "eeprom.h"

void display_main_menu()
{
    clcd_print(menu[menu_i],LINE1(1));
    clcd_print(menu[(menu_i)+1],LINE2(1));
    if(star==1)
    {
        clcd_putch('*',LINE1(0));
        clcd_putch(' ',LINE2(0));
    }
    else if(star==2)
    {
        clcd_putch('*',LINE2(0));
        clcd_putch(' ',LINE1(0));
    }
    
    key = read_switches(STATE_CHANGE);
    
    if(key==3)
    {
        star++;
        if(star>2)
        {
            star=2;
            if(menu_i<2)
                menu_i++;
        }
    }
    else if(key==2)
    {
        star--;
        if(star<1)
        {
            star=1;
            if(menu_i>0)
                menu_i--;
        }
    }
    else if(key==12)
    {
        CLEAR_DISP_SCREEN;
        state=e_dashboard;
    }
    
    else if(key==11&&menu_i==0)
    {
        if(star==1)
        {
            CLEAR_DISP_SCREEN;
            v_i=0;
            v=0;
            state=e_view_log;
        }
        else 
        {
            CLEAR_DISP_SCREEN;
            state=e_download_log;
            
        }
    }
    
    else if(key==11&&menu_i==1)
    {
        if(star==1)
        {
            CLEAR_DISP_SCREEN;
            state=e_download_log;
        }
        else
        {
            CLEAR_DISP_SCREEN;
            state=e_clear_log;
        }
    }
    else if(key==11&&menu_i==2)
    {
        if(star==1)
        {
            CLEAR_DISP_SCREEN;
            state=e_clear_log;
        }
        else 
        {
            CLEAR_DISP_SCREEN;
            //fld=0;
            hr=((time[0]-'0')*10)+(time[1]-'0');
            min=((time[3]-'0')*10)+(time[4]-'0');
            sec=((time[6]-'0')*10)+(time[7]-'0');
            state=e_set_time;
        }
    }
    
}