#include <xc.h>
#include "external_eeprom.h"
#include "main.h"

void event_store()
{
    if((ec%10)==0)
        add=0x00;
    
    for(int i=0;i<8;i++)
    {
        write_ex_eeprom(add++,time[i]);
    }
    for(int i=0;i<2;i++)
    {
        write_ex_eeprom(add++,event[index][i]);
    }
    write_ex_eeprom(add++,(speed/10));
    write_ex_eeprom(add++,(speed%10));
    ec++;
}
