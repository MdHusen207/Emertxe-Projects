#ifndef MAIN_H
#define MAIN_H

/* Enum for maintaining the app state */
typedef enum {
    e_dashboard, e_main_menu, e_view_log, e_set_time, e_download_log, e_clear_log
} State_t;

//char arr1[]="TIME      EV  SP";
char time[]="00:00:00";
unsigned int index=0;
char event[9][3]={"ON","GN","G1","G2","G3","G4","G5","GR","CL"};
unsigned int speed=0;
unsigned int key=0;
unsigned int acc=0;
char menu[4][13]={"View_log    ", "Download_log", "Clear_log   ", "Set_time    "};
unsigned int star=1;
unsigned int menu_i=0;
unsigned int ec=0;
unsigned int add=0x00;
char ev_list[10][20];
int r_add;
unsigned int r_i=0;
unsigned int r_j=0;
unsigned char clock_reg[3];
unsigned int v_i=0;
unsigned char s_time[7];
unsigned int hr;
unsigned int min;
unsigned int sec;
unsigned int fld=0;
unsigned long int t_del=1000;
int v=0;
//char waste[200];


extern State_t state; // App state

//Function declarations

//Dashboard function declaration
void view_dashboard(void);

//Storing events function declaration
void event_store(void);

//Password function declaration
void password(void);

//main menu function declaration
void display_main_menu(void);

//View log function declaration
void view_log(void);

//Reading events function declaration
void event_reader(void);

//Change password function declaration
void change_password(void);

//Set time function declaration
void set_time(void);

//Download log function _decleration
void download_log(void);

//Clear log function declaration
void clear_log(void);

#endif