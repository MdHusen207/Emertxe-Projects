#include <xc.h>
#include "main.h"
#include "external_eeprom.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "uart.h"
#include "ds1307.h"

void view_log()
{
    
    if(ec==0)
    {
        clcd_print("NoLog Present...",LINE1(0));
        for(unsigned long int del=500000;del--;);
        state=e_main_menu;
        CLEAR_DISP_SCREEN;
    }
    else
    {
    event_reader();
    //CLEAR_DISP_SCREEN;
    clcd_print(ev_list[v_i],LINE2(0));
    clcd_putch((v_i+'0'),LINE1(0));
    clcd_print("-TIME    EV  SP",LINE1(1));
    }
    key = read_switches(STATE_CHANGE);
    
    if(key==2)
    {            
        key=0;
        
        if(v_i!=9)
        {
            if(v_i<ec-1)
            v_i++;
        }
    }
    if(key==3)
    {
        key=0;
        if(v_i!=0)
        {
            v_i--;
        }
    }
    if(key==12)
    {
        key=0;
        CLEAR_DISP_SCREEN;
        menu_i=0;
        star=1;
        state=e_main_menu;
    }
    
}

void download_log()
{
    if(ec==0)
    {
        puts("NoLog Present...\n\r");
        state=e_main_menu;
        CLEAR_DISP_SCREEN;
    }
    else
    {
    event_reader();
    int l;
    if(ec>10)
        l=10;
    else 
        l=ec;
    puts("downloaded log\n\r");
    for(int k=0;k<l;k++)
    {
        puts( ev_list[k]);
        puts("\n\r");
    }
    
    CLEAR_DISP_SCREEN;
    clcd_print("downloading...",LINE1(0));
    for(unsigned long int del=1000000;del--;);
    state=e_main_menu;
    CLEAR_DISP_SCREEN;
    }
}

void clear_log()
{
    ec=0;
    add=0x00;
    clcd_print("Clearing...",LINE1(0));
    for(unsigned long int del=500000;del--;);
    state=e_main_menu;
    CLEAR_DISP_SCREEN;
}
void set_time()
{
    
    key=read_switches(STATE_CHANGE);
            
    if(key==12)
    {
        key=0;
        CLEAR_DISP_SCREEN;
        menu_i=0;
        star=1;
        state=e_main_menu;
    }
    
    if(key==11)
    {
        write_ds1307(HOUR_ADDR,((hr/10)<<4)|(hr%10));
        write_ds1307(MIN_ADDR,((min/10)<<4)|(min%10));
        write_ds1307(SEC_ADDR,((sec/10)<<4)|(sec%10));
        key=0;
        CLEAR_DISP_SCREEN;
        menu_i=0;
        star=1;
        state=e_main_menu;
    }
    
    //get_time();
    
    if(key==2)
    {
        fld++;
        if(fld>2)
            fld=0;
    }
    
    if(key==1)
    {
        if(fld==0)
        {
            hr++;
            if(hr==24)
            hr=0;
        }
         if(fld==1)
        {
            min++;
            if(min==60)
                min=0;
        }
        else if(fld==2)
        {
            sec++;
            if(sec==60)
                sec=0;
        }
    }
    
        time[0]=(hr/10)+'0';
        time[1]=(hr%10)+'0';
        time[3]=(min/10)+'0';
        time[4]=(min%10)+'0';
        time[6]=(sec/10)+'0';
        time[7]=(sec%10)+'0';
    
    if(t_del<=500)
    {
        if(fld==0)
        {
            time[0]=255;
            time[1]=255;
        }
        else
        {
            time[0]=(hr/10)+'0';
            time[1]=(hr%10)+'0';
        }
        
        if(fld==1)
        {
            time[3]=255;
            time[4]=255;
        }
        else
        {
            time[3]=(min/10)+'0';
            time[4]=(min%10)+'0';
        }
        
        if(fld==2)
        {
            time[6]=255;
            time[7]=255;
        }
        else
        {
            time[6]=(sec/10)+'0';
            time[7]=(sec%10)+'0';
        }
    }
    
    
    if(t_del--==0)t_del=1000;
    
    clcd_print("HH:MM:SS",LINE1(2));
    clcd_print(time,LINE2(2));
}