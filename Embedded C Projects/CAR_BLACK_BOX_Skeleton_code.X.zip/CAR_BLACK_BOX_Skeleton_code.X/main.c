/*
 * File:   main.c
 * Author: Mohammad Husen Chapparband
 * Roll : 24018_293
 * Project name: CAR_BLACK_BOX
 * Created on 30 January, 2025, 5:40 PM
 */

#include <xc.h>
//#include "black_box.h"
#include "clcd.h"
#include "main.h"
#include "adc.h"
#include "matrix_keypad.h"
//#include "eeprom.h"
#include "i2c.h"
#include "ds1307.h"
#include "uart.h"

State_t state = e_dashboard;

void init_config()
{
    init_i2c();
    init_ds1307();
    init_clcd();
    init_adc();
    init_uart();
    init_matrix_keypad();
}
static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}
void main(void) 
{
 
    init_config();
    if(ec==0)
    {
        get_time();
        event_store();
    }
        // Detect key press
    //unsigned static int i=0;

    
    while (1)
    {
        
        speed = read_adc(CHANNEL4)/10.33;
        
        if(index==0||index==1)
            speed=0;
        //clcd_putch('h', LINE2(0));
        if(state!=e_set_time)
        get_time();
        
        switch (state)
        {
            case e_dashboard:
                // Display dashboard
                view_dashboard();
                break;
            
            case e_main_menu:
                // Display dashboard
                display_main_menu();
                break;
            
            case e_view_log:
                // Display dashboard
                view_log();
                break;
                 
            case e_download_log:
                download_log();
                break;
                
            case e_clear_log:
                clear_log();
                break;
                
                      
            case e_set_time:
                set_time();
                break;
                
        }
        
    }
    
}
