#include <xc.h>
#include "clcd.h"

static void init_config(void)
{
    init_clcd();
  
}

void main(void)
{
    init_config();
    unsigned static int i=0;
    unsigned char arr1[]="TIME    EV  SP";
    //unsigned char ch=arr[i++];
    while (1)
    {
        for(unsigned long int t=200;t--;)
            //t=50000;
        //clcd_putch('H', LINE1(0)); 
        clcd_print(arr, LINE2(0)); 
        
        for(int j=15;j>=0;j--)
            arr[j]=arr[(j-1)%16];
        
    }
}