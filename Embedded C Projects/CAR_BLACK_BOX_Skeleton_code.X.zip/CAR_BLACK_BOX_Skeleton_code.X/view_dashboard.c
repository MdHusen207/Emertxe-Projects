/*
 * File:   view_dashboard.c
 * Author: Mohammad Husen
 *
 * Created on 21 January, 2025, 8:44 AM
 */


#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "matrix_keypad.h"

void view_dashboard() 
{
    clcd_print("TIME      EV  SP", LINE1(0));
    clcd_print(time, LINE2(0));
    clcd_print(event[index], LINE2(10));
    clcd_putch((speed/10)+'0', LINE2(14));
    clcd_putch((speed%10)+'0', LINE2(15));
    
    
    key = read_switches(STATE_CHANGE);
    
    
    if(key == 2 && acc==0)
    {
        if(index<7)
        index++;
        key=0;
        event_store();
    }
    else if(key == 3 && acc==0)
    {
        if(index>1)
        index--;
        key=0;
        event_store();
    }
    else if(key==1 && acc==0)
    {
        index=8;
        acc=1;
        key=0;
        event_store();
    }
    else if((key==2||key==3)&&acc==1)
    {
        acc=0;
        index=1;
        key=0;
        event_store();
    }
    
    if(key==11)
    {
        CLEAR_DISP_SCREEN;
        menu_i=0;
        star=1;
        state = e_main_menu;

    }
}
